Page({
  data: {
    showName: false,
    name: 'Dell',
    showHelloWorld: false,
  },
  handleTap() {
    this.setData({showName: false})
  }
})
