Page({
  data: {
    content: 'this is content'
  },
  handleTap() {
    this.setData({showName: false})
  }
})
