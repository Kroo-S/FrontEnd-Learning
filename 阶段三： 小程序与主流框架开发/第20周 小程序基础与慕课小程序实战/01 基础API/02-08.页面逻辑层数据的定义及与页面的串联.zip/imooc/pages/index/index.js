Page({
  data: {
    name: 'dell'
  },
  changeName() {
    this.setData({
      name: 'lee'
    })
  }
})
