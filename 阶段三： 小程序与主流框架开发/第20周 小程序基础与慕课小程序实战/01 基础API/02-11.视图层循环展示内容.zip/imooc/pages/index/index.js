Page({
  data: {
    users: [1,2,3]
  },
  handleTap() {
    this.setData({showName: false})
  }
})
